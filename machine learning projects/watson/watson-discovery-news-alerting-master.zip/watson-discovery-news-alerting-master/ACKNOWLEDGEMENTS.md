# Acknowledgements

* [Erik Erwitt](https://github.com/eerwitt) - original developer.

Erik has also contributed some blogs:
[Screencast Notes](https://github.com/IBM/watson-discovery-news-alerting/blob/master/doc/_screencast_notes.md) and 
[Upgrading AlchemyData News to Watson Discovery News](https://github.com/IBM/watson-discovery-news-alerting/blob/master/doc/_upgrading_alchemydata_news_to_watson_discovery.md)
